from ruxit.api.base_plugin import RemoteBasePlugin
from ruxit.api.exceptions import ConfigException
import redis
from collections import namedtuple, defaultdict
import time
import socket

import logging

log = logging.getLogger(__name__)

QueryDesc = namedtuple('QueryDesc', ['is_per_second'])
BindingData = namedtuple('BindingData', ['host', 'port'])
CollectedMetric = namedtuple('CollectedMetric', ['value', 'is_per_second', 'dim'])


class RemoteRedisPlugin(RemoteBasePlugin):

    def initialize(self, **kwargs):
        config = kwargs['config']
        self.timeseries = kwargs['json_config']['metrics']

        if 'host' in config and config['host'] != '':
            self.host = config['host']
        else:
            raise ConfigException("'Host' field is not present in configuration")
        if 'port' in config and config['port'] != '':
            self.port = config['port']
        else:
            raise ConfigException("'Port' field is not present in configuration")
        if 'friendlydbname' in config:
            self.friendlydbname = config['friendlydbname']
        else:
            self.friendlydbname = None
        if 'auth_connection_password' in config and config['auth_connection_password'] != '':
            self.connection_password = config['auth_connection_password']
        else:
            self.connection_password = ''

        self.default_user_commands = config['default_user_commands']
        if not self.default_user_commands:
            if 'auth_user' in config:
                self.auth_user = config['auth_user']
            else:
                raise ConfigException("'User' field is not present in configuration")
            if 'auth_password' in config:
                self.auth_password = config['auth_password']
            else:
                raise ConfigException("'User Password' field is not present in configuration")

        self.r = None

        self.config_command = "CONFIG"
        self.info_command = "INFO"
        self.slowlog_command = "SLOWLOG"

        self._connect()
        self.redis_metrics = {}
        self.redis_db_metrics = {}
        self._initialize_metrics()
        self.hit_ratio_old = {'keyspace_hits': None, 'keyspace_misses': None}
        self.hit_ratio = {'keyspace_hits': None, 'keyspace_misses': None}

    def _connect(self):
        try:
            log.info("Connecting via default user")
            if self.connection_password != '':
                log.info("Trying to connect with a password")
                self.r = redis.StrictRedis(host=self.host,
                                           port=self.port,
                                           password=self.connection_password)
            else:
                log.info("No password supplied, trying to connect")
                self.r = redis.StrictRedis(host=self.host,
                                           port=self.port)
            if not self.default_user_commands:
                log.info("Using different user to run commands : " + self.auth_user)
                user_auth_string = "AUTH " + self.auth_user + " " + self.auth_password
                user_auth = self.r.execute_command(user_auth_string)

            self._get_redis_info()
        except redis.exceptions.ResponseError as e:
            if str(e) == "unknown command 'AUTH'":
                try:
                    self.r = redis.StrictRedis(host=self.host,
                                               port=self.port)
                    self._get_redis_info()
                except redis.exceptions.ResponseError as e:
                    if str(e) == "NOAUTH Authentication required.":
                        raise ConfigException("Password is needed.")
                    else:
                        raise ConfigException(e.args) from e
                except redis.exceptions.ConnectionError as e:
                    raise ConfigException(e.args) from e
            else:
                raise ConfigException(e.args) from e

        except redis.exceptions.ConnectionError as e:
            raise ConfigException(e.args) from e

    def _initialize_metrics(self):
        redis_metrics = {}
        redis_db_metrics = {}

        try:
            for metric in self.timeseries:
                if 'statetimeseries' in metric:
                    continue
                query = metric['timeseries']['key']
                if metric['timeseries']['unit'] == 'PerSecond':
                    per_second = True
                else:
                    per_second = False
                timeseries_dim = metric['timeseries']['dimensions']
                if len(timeseries_dim) == 0:
                    redis_metrics[query] = QueryDesc(per_second)
                else:
                    redis_db_metrics[query] = QueryDesc(per_second)
        except KeyError:
            log.info(self, exc_info=1)

        self.redis_metrics = redis_metrics
        self.redis_db_metrics = redis_db_metrics

    def query(self, **kwargs):
        self._create_device_and_group()
        self._report_endpoint_and_port()
        try:
            info = self._get_info_data()
            self._report_role(info)
            self._report_state(info)

            self.databases_no = int(self._get_redis_config().get('databases', 0))
            if (self.databases_no == 0):
                self.databases_no = self._get_num_databases()
            self.redis_collected_metrics = defaultdict(list)
            for query, query_desc in self.redis_metrics.items():
                self._get_redis_metric(query, query_desc, info)
            for query, query_desc in self.redis_db_metrics.items():
                self._get_redis_metric(query, query_desc, info, database_metric=True)

            self._calculate_and_report_memory_usage()
            self._calculate_and_report_hit_ratio()
            self._get_and_report_slowlog_len()
            self._report_collected_metrics()

        except (redis.exceptions.ResponseError, redis.exceptions.ConnectionError) as ex:
            raise ConfigException(ex.args) from ex

    def _create_device_and_group(self):
        cdGroup = self.topology_builder.create_group("Redis", "Redis")
        if self.friendlydbname:
            deviceName = self.host + ":" + self.port + " - " + self.friendlydbname
        else:
            deviceName = self.host + ":" + self.port
        self.device = cdGroup.create_device(deviceName, deviceName)

    def _report_endpoint_and_port(self):
        DNSNamesList = list()
        portList = [self.port]
        ipAddress = socket.gethostbyname(self.host)
        if self.host != ipAddress:
            DNSNamesList.append(self.host)
            self.device.add_endpoint(ip=str(ipAddress), port_list=portList, dnsNames=DNSNamesList)
        else:
            self.device.add_endpoint(ip=str(ipAddress), port_list=portList)

    def _get_info_data(self):
        time_start = time.time()
        info = self._get_redis_info()
        time_stop = time.time()

        self.device.absolute(key='responsiveness', value=round((time_stop - time_start) * 1000, 2))
        return info

    def _report_role(self, info):
        redis_mode = info.get('redis_mode', None)
        if redis_mode is not None:
            self._report_contributed_name(redis_mode, "Redis Mode")

        redis_role = info.get('role', None)
        if redis_role is not None:
            self._report_contributed_name('Redis' + ' (' + redis_role + ')', "Redis Role")

    def _report_state(self, info):
        try:
            if info.get('role', None) == 'slave':
                state = None
                link_status = info.get('master_link_status', None)
                sync_in_progress = info.get('master_sync_in_progress', None)
                if link_status == "up" and sync_in_progress == 0:
                    state = "Synchronized"
                elif link_status == "down":
                    if sync_in_progress == 0:
                        state = "Unsynchronized"
                    elif sync_in_progress == 1:
                        state = "Sync_in_progress"
                self.device.state_metric(key='slave_state', value=state)
        except:
            log.info(self, exc_info=1)

    def _report_contributed_name(self, value, key):
        self.device.report_property(key, value)

    def _get_redis_metric(self, query, query_desc, info, database_metric=False):
        try:
            if not database_metric:
                query_value = info.get(query, 'n/a')
                if query_value != 'n/a':
                    self.redis_collected_metrics[query].append(
                        CollectedMetric(query_value, query_desc.is_per_second, None))
                if query in ['keyspace_hits', 'keyspace_misses']:
                    self.hit_ratio[query] = int(query_value)
            else:
                for x in range(self.databases_no):
                    db_name = 'db' + str(x)
                    dim = {'database': db_name}
                    query_value = info.get(db_name, {}).get(query, 'n/a')
                    if query_value != 'n/a':
                        self.redis_collected_metrics[query].append(
                            CollectedMetric(query_value, query_desc.is_per_second, dim))
        except:
            log.info(self, exc_info=1)

    def _calculate_and_report_memory_usage(self):
        if 'used_memory' not in self.redis_collected_metrics or 'maxmemory' not in self.redis_collected_metrics:
            log.info('Cannot calculate Redis memory usage as "used memory" or "maxmemory" data is not available')
            return
        used_memory = int(self.redis_collected_metrics['used_memory'][0].value)
        maxmemory = int(self.redis_collected_metrics['maxmemory'][0].value)
        if maxmemory != 0:
            self.device.absolute(key='maxmemory', value=maxmemory)
            self.device.absolute(key='memory_usage', value=used_memory / maxmemory * 100)

    def _calculate_and_report_hit_ratio(self):
        try:
            if self.hit_ratio_old['keyspace_hits'] is not None and self.hit_ratio_old['keyspace_misses'] is not None:
                hits = self.hit_ratio['keyspace_hits'] - self.hit_ratio_old['keyspace_hits']
                misses = self.hit_ratio['keyspace_misses'] - self.hit_ratio_old['keyspace_misses']
                if hits + misses > 0:
                    calculated_hit_ratio = hits / (hits + misses) * 100
                    self.device.absolute(key='hit_ratio', value=calculated_hit_ratio)
        except KeyError:
            log.info(self, exc_info=1)

        self.hit_ratio_old['keyspace_hits'] = self.hit_ratio['keyspace_hits']
        self.hit_ratio_old['keyspace_misses'] = self.hit_ratio['keyspace_misses']

    def _get_and_report_slowlog_len(self):
        try:
            self.device.relative(key='slowlog_len', value=self._get_redis_slowlog_len())
        except:
            log.info(self, exc_info=1)

    def _report_collected_metrics(self):
        for query, metrics in self.redis_collected_metrics.items():
            for metric in metrics:
                if metric.is_per_second:
                    self.device.per_second(key=query, value=metric.value, dimensions=metric.dim)
                else:
                    self.device.absolute(key=query, value=metric.value, dimensions=metric.dim)

    def _get_num_databases(self):
        log.info("Trying again to get Num of DBs")
        keyspaces = self.r.execute_command("INFO Keyspace")
        keyspaceLines = keyspaces.splitlines()
        numDBs = len(keyspaceLines) - 1
        if numDBs <= 0:
            return 0
        else:
            return numDBs

    def _get_redis_info(self):
        if self.info_command is not "INFO":
            info_b = self.r.execute_command(self.info_command)
            return self.r.response_callbacks['INFO'](info_b)
        else:
            return self.r.info()

    def _get_redis_config(self):
        if self.config_command is not "CONFIG":
            config_b = self.r.execute_command(self.config_command + ' GET *')
            return self.r.response_callbacks['CONFIG GET'](config_b)
        else:
            return self.r.config_get()

    def _get_redis_slowlog_len(self):
        if self.slowlog_command is not "SLOWLOG":
            return self.r.execute_command(self.slowlog_command + ' LEN')
        else:
            return self.r.slowlog_len()
