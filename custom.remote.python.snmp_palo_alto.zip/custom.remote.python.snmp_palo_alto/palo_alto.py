from typing import List, Generator
import logging

from ruxit.api.exceptions import ConfigException

from pysnmp.hlapi import (
    SnmpEngine,
    CommunityData,
    UdpTransportTarget,
    ContextData,
    ObjectType,
    ObjectIdentity,
    nextCmd,
    UsmUserData,
    usmHMACMD5AuthProtocol,
    usmHMACSHAAuthProtocol,
    usmHMAC128SHA224AuthProtocol,
    usmHMAC192SHA256AuthProtocol,
    usmHMAC256SHA384AuthProtocol,
    usmHMAC384SHA512AuthProtocol,
    usmNoAuthProtocol,
    usmDESPrivProtocol,
    usm3DESEDEPrivProtocol,
    usmAesCfb128Protocol,
    usmAesCfb192Protocol,
    usmAesCfb256Protocol,
    usmNoPrivProtocol,
)

default_log = logging.getLogger(__name__)


AUTHORIZATION_PROTOCOLS = {
    "md5": usmHMACMD5AuthProtocol,
    "sha": usmHMACSHAAuthProtocol,
    "sha224": usmHMAC128SHA224AuthProtocol,
    "sha256": usmHMAC192SHA256AuthProtocol,
    "sha384": usmHMAC256SHA384AuthProtocol,
    "sha512": usmHMAC384SHA512AuthProtocol,
    "noauth": usmNoAuthProtocol,
}

PRIVACY_PROTOCOLS = {
    "des": usmDESPrivProtocol,
    "3des": usm3DESEDEPrivProtocol,
    "aes": usmAesCfb128Protocol,
    "aes192": usmAesCfb192Protocol,
    "aes256": usmAesCfb256Protocol,
    "nopriv": usmNoPrivProtocol,
}

IFSTATUS = {1: "UP", 2: "DOWN", 3: "OTHER"}


def get_oid_value(oid: str, varbinds: List[ObjectType]):
    for v in varbinds:
        varbind_oid = str(v[0].getOid())
        if oid in varbind_oid or varbind_oid in oid:
            return v[1]._value
    return 0


class Memory:
    oids = ["1.3.6.1.2.1.25.2.3.1.3", "1.3.6.1.2.1.25.2.3.1.5", "1.3.6.1.2.1.25.2.3.1.6"]

    def __init__(self, varbinds: List[ObjectType]):
        self.name = get_oid_value(self.oids[0], varbinds).decode()
        self.size = get_oid_value(self.oids[1], varbinds)
        self.used = get_oid_value(self.oids[2], varbinds)

    def __str__(self):
        return f"Memory {self.name} ({self.used}/{self.size})"


class Interface:
    oids = [
        "1.3.6.1.2.1.2.2.1.2",  # Name
        "1.3.6.1.2.1.2.2.1.8",  # Up/Down
        "1.3.6.1.2.1.2.2.1.5",  # Speed
        "1.3.6.1.2.1.2.2.1.10",  # In Oct
        "1.3.6.1.2.1.2.2.1.14",  # In Err
        "1.3.6.1.2.1.2.2.1.13",  # In Discards
        "1.3.6.1.2.1.2.2.1.16",  # Out Oct
        "1.3.6.1.2.1.2.2.1.20",  # Out Err
        "1.3.6.1.2.1.2.2.1.19",  # Out Discards
        "1.3.6.1.2.1.31.1.1.1.18",  # Alias
    ]

    def __init__(self, varbinds: List[ObjectType]):

        self.name = get_oid_value(self.oids[0], varbinds).decode()
        self.ifstatus = IFSTATUS.get(get_oid_value(self.oids[1], varbinds), "OTHER")
        self.speed = get_oid_value(self.oids[2], varbinds)
        self.in_oct = get_oid_value(self.oids[3], varbinds)
        self.in_err = get_oid_value(self.oids[4], varbinds)
        self.in_discards = get_oid_value(self.oids[5], varbinds)
        self.out_oct = get_oid_value(self.oids[6], varbinds)
        self.out_err = get_oid_value(self.oids[7], varbinds)
        self.out_discards = get_oid_value(self.oids[8], varbinds)
        self.alias = get_oid_value(self.oids[9], varbinds).decode()

    def __str__(self):
        return f"Interface '{self.name} ({self.alias})', Status: {self.ifstatus}, InOct: {self.in_oct}, OutOct: {self.out_oct}, InErr: {self.in_err}, OutErr: {self.out_err}, Speed: {self.speed}"


class GatewayUtilization:

    oids = [
        "1.3.6.1.4.1.25461.2.1.2.5.1.1",  # panGPGWUtilizationPct
        "1.3.6.1.4.1.25461.2.1.2.5.1.2",  # panGPGWUtilizationMaxTunnels
        "1.3.6.1.4.1.25461.2.1.2.5.1.3",  # panGPGWUtilizationActiveTunnels
        "1.3.6.1.4.1.25461.2.1.2.3.1",  # panSessionUtilization
        "1.3.6.1.4.1.25461.2.1.2.3.3",  # panSessionActive
        "1.3.6.1.4.1.25461.2.1.2.3.2",  # panSessionMax
        "1.3.6.1.4.1.25461.2.1.2.3.4",  # panSessionActiveTcp
        "1.3.6.1.4.1.25461.2.1.2.3.5",  # panSessionActiveUdp
        "1.3.6.1.4.1.25461.2.1.2.3.6",  # panSessionActiveICMP
    ]

    def __init__(self, varbinds: List[ObjectType]):

        self.gp_gateway_pct = get_oid_value(self.oids[0], varbinds)
        self.gp_gateway_max_tunnels = get_oid_value(self.oids[1], varbinds)
        self.gp_gateway_active_tunnels = get_oid_value(self.oids[2], varbinds)
        self.session_pct = get_oid_value(self.oids[3], varbinds)
        self.active_sessions = get_oid_value(self.oids[4], varbinds)
        self.max_sessions = get_oid_value(self.oids[5], varbinds)
        self.sessions_tcp = get_oid_value(self.oids[6], varbinds)
        self.sessions_udp = get_oid_value(self.oids[7], varbinds)
        self.sessions_icmp = get_oid_value(self.oids[8], varbinds)

    def __str__(self):
        return f"Gateway Utilization: Global Protect %: {self.gp_gateway_pct}, Max Tunnels: {self.gp_gateway_max_tunnels}, Active Tunnels: {self.gp_gateway_active_tunnels}, Sessions %: {self.session_pct}, Active Sessions: {self.active_sessions} "


class CPU:

    oids = ["1.3.6.1.2.1.25.3.3.1.2"]

    def __init__(self, varbinds: List[ObjectType]):

        self.usage = get_oid_value(self.oids[0], varbinds)

    def __str__(self):
        return f"CPU Usage: {self.usage}"


class Properties:

    oids = [
        "1.3.6.1.2.1.1.1",  # 'sysDescr',
        "1.3.6.1.2.1.1.2",  # 'sysObjectID',
        "1.3.6.1.2.1.1.3",  # 'sysUpTime',
        "1.3.6.1.2.1.1.4",  # 'sysContact',
        "1.3.6.1.2.1.1.5",  # 'sysName',
        "1.3.6.1.2.1.1.6",  # 'sysLocation',
        "1.3.6.1.2.1.1.8",  # 'sysORLastChange'
    ]

    def __init__(self, varbinds: List[ObjectType]):
        self.description = get_oid_value(self.oids[0], varbinds).decode()
        self.uptime: int = get_oid_value(self.oids[2], varbinds)
        self.contact = get_oid_value(self.oids[3], varbinds).decode()
        self.name = get_oid_value(self.oids[4], varbinds).decode()
        self.location = get_oid_value(self.oids[5], varbinds).decode()
        self.last_change = get_oid_value(self.oids[6], varbinds)

    def __repr__(self):
        return f"Properties({self.description}, {self.uptime}, {self.contact}, {self.name}, {self.location}, {self.last_change})"


class VsysUtilization:
    oids = [
        "1.3.6.1.4.1.25461.2.1.2.3.9.1.1",  # 'panVsysId'
        "1.3.6.1.4.1.25461.2.1.2.3.9.1.2",  # 'panVsysName'
        "1.3.6.1.4.1.25461.2.1.2.3.9.1.3",  # 'panVsysSessionUtilizationPct'
        "1.3.6.1.4.1.25461.2.1.2.3.9.1.4",  # 'panVsysActiveSessions'
        "1.3.6.1.4.1.25461.2.1.2.3.9.1.5",  # 'panVsysMaxSessions'
    ]

    def __init__(self, varbinds: List[ObjectType]):
        self.id = get_oid_value(self.oids[0], varbinds)
        self.name = get_oid_value(self.oids[1], varbinds).decode()
        self.session_utilization = get_oid_value(self.oids[2], varbinds)
        self.active_sessions = get_oid_value(self.oids[3], varbinds)
        self.max_sessions = get_oid_value(self.oids[4], varbinds)


class Sensor:
    oids = ["1.3.6.1.2.1.47.1.1.1.1.7", "1.3.6.1.2.1.99.1.1.1.4", "1.3.6.1.2.1.99.1.1.1.6"]

    def __init__(self, varbinds: List[ObjectType]):
        self.name = get_oid_value(self.oids[0], varbinds).decode()
        self.value = get_oid_value(self.oids[1], varbinds)
        self.sensor_type = get_oid_value(self.oids[2], varbinds)
        if type(self.sensor_type) == bytes:
            self.sensor_type = self.sensor_type.decode()
        self.sensor_type = str(self.sensor_type)

    def __repr__(self):
        return f"Sensor({self.name}: {self.value} {self.sensor_type})"


class PaloAlto:
    def __init__(
        self,
        version,
        host,
        port,
        community,
        auth_pass=None,
        priv_pass=None,
        auth_protocol=None,
        priv_protocol=None,
        log: logging = default_log,
    ):
        self.host = host
        self.port = port
        self._community = community
        self._engine = SnmpEngine()
        self._context = ContextData()
        self._transport = UdpTransportTarget((self.host, self.port), timeout=20, retries=0)
        self.log = log

        self._auth = CommunityData(self._community)
        if version == "v3":
            self._auth = UsmUserData(
                community,
                auth_pass,
                priv_pass,
                AUTHORIZATION_PROTOCOLS.get(auth_protocol, None),
                PRIVACY_PROTOCOLS.get(priv_protocol, None),
            )

    def get_bulk(self, oids: List[str]) -> List[List]:
        request_varbinds = [ObjectType(ObjectIdentity(oid)) for oid in oids]

        for error, error_status, error_index, varbinds in nextCmd(
            self._engine,
            self._auth,
            self._transport,
            self._context,
            *request_varbinds,
            lexicographicMode=False,
        ):
            if error is None and not error_status:
                varbinds = [varbind for varbind in varbinds if isinstance(varbind, ObjectType)]
                yield varbinds
            else:
                error_message = f"Error getting OIDs {oids}: {error} {error_status}"
                self.log.error(error_message)
                raise ConfigException(error_message)

    def parse_bulk(self, _class):
        self.log.debug(f"Attempting to obtain {_class.oids} for {_class}")
        for varbinds in self.get_bulk(_class.oids):
            yield _class(varbinds)

    def get_cpu(self) -> Generator[CPU, None, None]:
        return self.parse_bulk(CPU)

    def get_storage(self) -> Generator[Memory, None, None]:
        return self.parse_bulk(Memory)

    def get_interfaces(self) -> Generator[Interface, None, None]:
        return self.parse_bulk(Interface)

    def get_gateway_utilization(self) -> Generator[GatewayUtilization, None, None]:
        return self.parse_bulk(GatewayUtilization)

    def get_properties(self) -> Generator[Properties, None, None]:
        return self.parse_bulk(Properties)

    def get_vsys_utilization(self) -> Generator[VsysUtilization, None, None]:
        return self.parse_bulk(VsysUtilization)

    def get_sensors(self) -> Generator[Sensor, None, None]:
        return self.parse_bulk(Sensor)


def main():
    import json

    log = logging.getLogger(__name__)
    log.setLevel(logging.DEBUG)
    st = logging.StreamHandler()
    fmt = logging.Formatter("%(asctime)s - %(levelname)s - %(name)s - %(thread)d - %(filename)s:%(lineno)d - %(message)s")
    st.setFormatter(fmt)
    log.addHandler(st)

    with open("properties.json", "r") as f:
        config = json.load(f)

    host, port = config.get("hostname").split(":")

    p = PaloAlto(config.get("snmp_version"), host, port, config.get("snmp_user"), log=log)

    # for cpu in p.get_cpu():
    #     print(cpu)
    # for mem in p.get_storage():
    #     print(mem)
    # for interface in p.get_interfaces():
    #     print(interface)
    # for ut in p.get_gateway_utilization():
    #     print(ut)
    # for pr in p.get_properties():
    #     print(pr)
    # for v in p.get_vsys_utilization():
    #     print(v)
    for sensor in p.get_sensors():
        print(sensor)
    # snmpwalk -v 2c -c network/firewall/paloalto-pa-5000 ec2-3-87-63-112.compute-1.amazonaws.com::1024 1.3.6.1.2.1.2.2.1


if __name__ == "__main__":
    main()
