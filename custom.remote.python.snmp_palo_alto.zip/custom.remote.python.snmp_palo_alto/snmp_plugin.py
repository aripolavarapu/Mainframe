from datetime import timedelta, datetime
from statistics import mean

from palo_alto import PaloAlto
from plugin_utils import time_it, exception_logger

from ruxit.api.base_plugin import RemoteBasePlugin


class PaloAltoPlugin(RemoteBasePlugin):
    def initialize(self, **kwargs):
        self.speed_cache = {}  # Used to calculate interface speed

    def query(self, **kwargs):

        hostname = self.config.get("hostname", "localhost")
        port = 161
        if ":" in hostname:
            hostname, port = hostname.split(":")

        version = self.config.get("snmp_version")
        community = self.config.get("snmp_user", "public")
        auth_pass = self.config.get("auth_key", None)
        priv_pass = self.config.get("priv_key", None)
        auth_protocol = self.config.get("auth_protocol", None)
        priv_protocol = self.config.get("priv_protocol", None)
        self.logger.setLevel(self.config.get("log_level", "INFO"))

        group = self.topology_builder.create_group(
            self.config.get("group", "Network Devices"), self.config.get("group", "Network Devices")
        )
        device_name = self.config.get("device_name", self.config.get("hostname"))
        self.logger.info(f"Creating device. Name: {device_name}, Hostname: {hostname}")
        self.device = group.create_device(device_name)

        self.palo_alto = PaloAlto(version, hostname, int(port), community, auth_pass, priv_pass, auth_protocol, priv_protocol)

        self.logger.info("Getting properties...")
        start = datetime.now().timestamp()

        try:
            properties = self.palo_alto.get_properties()
            self.device.absolute("response_time", (datetime.now().timestamp() - start) * 1000)
            for prop in properties:
                self.device.absolute("availability", 100)
                self.device.report_property("Name", prop.name)
                self.device.report_property("Description", prop.description)
                self.device.report_property("Location", prop.location)
                self.device.report_property("Contact", prop.contact)
                self.device.report_property("Last change", str(prop.last_change))
                self.device.report_property("Uptime", f"{timedelta(seconds=prop.uptime / 100)}")

            self.report_cpu()
            self.report_memory()
            self.report_gateway_usage()
            self.report_interfaces()
            self.report_vsys_usage()
            self.report_sensors()

        except Exception as e:
            self.logger.exception(f"Could not collect device properties for {hostname}: {e}")
            self.device.absolute("availability", 0)

        response_time = (datetime.now().timestamp() - start) * 1000
        self.logger.info(f"Device responded to all SNMP queries in {response_time:.2f}ms")

    @time_it
    @exception_logger
    def report_cpu(self):
        self.logger.info("Obtaining CPU metrics")
        cpus = ["cpu_system", "cpu_management"]
        values = [cpu.usage for cpu in self.palo_alto.get_cpu()]

        for cpu, value in zip(cpus, values):
            self.device.absolute(cpu, value)

    @time_it
    @exception_logger
    def report_memory(self):
        self.logger.info("Obtaining memory/storage metrics")
        for memory in self.palo_alto.get_storage():
            used_pct = memory.used / memory.size * 100 if memory.size > 0 else 0
            self.device.absolute("mem_pct", used_pct, dimensions={"Storage": memory.name})

    @time_it
    @exception_logger
    def report_gateway_usage(self):
        self.logger.info("Obtaining gateway usage metrics")
        for gateway_util in self.palo_alto.get_gateway_utilization():
            self.device.absolute(
                "gateway_usage",
                gateway_util.gp_gateway_active_tunnels / gateway_util.gp_gateway_max_tunnels
                if gateway_util.gp_gateway_max_tunnels > 0
                else 0,
            )
            self.device.absolute(
                "session_usage", gateway_util.active_sessions / gateway_util.max_sessions if gateway_util.max_sessions > 0 else 0
            )
            self.device.absolute("active_tunnels", gateway_util.gp_gateway_active_tunnels)
            self.device.absolute("max_tunnels", gateway_util.gp_gateway_max_tunnels)
            self.device.absolute("sessions", gateway_util.active_sessions)
            self.device.absolute("max_sessions", gateway_util.max_sessions)
            self.device.absolute("sessions_tcp", gateway_util.sessions_tcp)
            self.device.absolute("sessions_udp", gateway_util.sessions_udp)
            self.device.absolute("sessions_icmp", gateway_util.sessions_icmp)

    @time_it
    @exception_logger
    def report_vsys_usage(self):
        self.logger.info("Obtaining VSYS usage metrics")
        for vsys_utilization in self.palo_alto.get_vsys_utilization():
            self.device.absolute("vsys_max_sessions", vsys_utilization.max_sessions, dimensions={"Vsys": vsys_utilization.name})
            self.device.absolute(
                "vsys_active_sessions", vsys_utilization.active_sessions, dimensions={"Vsys": vsys_utilization.name}
            )
            self.device.absolute(
                "vsys_session_utilization", vsys_utilization.session_utilization, dimensions={"Vsys": vsys_utilization.name}
            )

    @time_it
    @exception_logger
    def report_interfaces(self):
        self.logger.info("Obtaining interface metrics")
        for interface in self.palo_alto.get_interfaces():
            name = interface.name
            if self.config.get("add_alias") and interface.alias:
                name = f"{name} ({interface.alias})"

            self.device.per_second("if_in", interface.in_oct, dimensions={"Interface": name})
            self.device.per_second("if_out", interface.out_oct, dimensions={"Interface": name})
            self.device.relative("if_in_err", interface.in_err, dimensions={"Interface": name})
            self.device.relative("if_out_err", interface.out_err, dimensions={"Interface": name})
            self.device.relative("if_in_discards", interface.in_discards, dimensions={"Interface": name})
            self.device.relative("if_out_discards", interface.out_discards, dimensions={"Interface": name})
            self.device.state_metric("if-status", interface.ifstatus, dimensions={"Interface": name})

            if interface.name in self.speed_cache:
                # https://www.cisco.com/c/en/us/support/docs/ip/simple-network-management-protocol-snmp/8141-calculate-bandwidth-snmp.html
                if interface.speed > 0:
                    in_util = (
                        (interface.in_oct - self.speed_cache[interface.name]["if_in"])
                        * 8
                        * 100
                        / ((datetime.now().timestamp() - self.speed_cache[interface.name]["timestamp"]) * interface.speed)
                    )
                    out_util = (
                        (interface.out_oct - self.speed_cache[interface.name]["if_out"])
                        * 8
                        * 100
                        / ((datetime.now().timestamp() - self.speed_cache[interface.name]["timestamp"]) * interface.speed)
                    )
                    self.device.absolute("if_in_util", in_util, dimensions={"Interface": interface.name})
                    self.device.absolute("if_out_util", out_util, dimensions={"Interface": interface.name})

            self.speed_cache[interface.name] = {
                "if_in": interface.in_oct,
                "if_out": interface.out_oct,
                "timestamp": datetime.now().timestamp(),
            }

    @time_it
    @exception_logger
    def report_sensors(self):
        self.logger.info("Obtaining sensor metrics")
        for sensor in self.palo_alto.get_sensors():
            if "rpm" in sensor.sensor_type.lower():
                self.device.absolute("rpm", sensor.value, dimensions={"Sensor": sensor.name})
            else:
                self.device.absolute("temperature", sensor.value, dimensions={"Sensor": sensor.name})
